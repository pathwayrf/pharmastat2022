rm(list=ls())
library(ggpubr)

## prepare data
## CA(cond), matching, weighting(no trim), weighting(trim 0.1), no borrow(cox), full borrow(cox)
setwd("~/Project/DLBCL")

plot_power <- function(dt,method,short.lab=F){
  dt <- dt[dt$method==method,]
  dt <- rbind(dt,dt2)
  dt$cf <- factor(dt$cf,levels=c("none","cov2","cov2+3","No borrowing"))
  pp <- ggline(dt,y="power", x="ssExt",
               color = "cf", 
               linetype = "cf",
               ylim = c(0.4,1),
               xlim = c(50,450),
               ylab = "Power",
               xlab = "Ext ctrl sample size",numeric.x.axis = T)+
    scale_color_discrete(name = "Confounding")+
    scale_linetype_discrete(name = "Confounding")+
    theme(plot.title = element_text(hjust = 0.5),
          legend.position = "right",
          text = element_text(size = 16),
          legend.key.size = unit(2, 'cm'),
          legend.text = element_text(size=16),
          legend.title = element_text(size=16),
          strip.text = element_text(size=14),
          axis.text.x = element_text(angle = 45,size = 12,vjust = 0.5))
  
  if(!short.lab){
    pp <- facet(pp,facet.by = "setting",panel.labs=list(setting=c("Large difference","No difference","Large reverse")))
  }else{
    pp <- facet(pp,facet.by = "setting")
  }
  pp
}

plot_t1e <- function(dt,method,short.lab=F){
  dt <- dt[dt$method==method,]
  dt <- rbind(dt,dt2)
  dt$cf <- factor(dt$cf,levels=c("none","cov2","cov2+3","No borrowing"))
  
  pp <- ggline(dt,y="t1e", x="ssExt",
               color = "cf", 
               linetype = "cf",
               ylim = c(0,0.1),
               xlim = c(50,450),
               ylab = "T1E",
               xlab = "Ext ctrl sample size",numeric.x.axis = T)+
    geom_hline(yintercept = 0.025,linetype = "dashed")+
    scale_color_discrete(name = "Confounding")+
    scale_linetype_discrete(name = "Confounding")+
    theme(plot.title = element_text(hjust = 0.5),
          legend.position = "right",
          text = element_text(size = 16),
          legend.key.size = unit(2, 'cm'),
          legend.text = element_text(size=16),
          legend.title = element_text(size=16),
          strip.text = element_text(size=14),
          axis.text.x = element_text(angle = 45,size = 12,vjust = 0.5))

  if(!short.lab){
    pp <- facet(pp,facet.by = "setting",panel.labs=list(setting=c("Large difference","No difference","Large reverse")))
  }else{
    pp <- facet(pp,facet.by = "setting")
  }
  pp
}


# plot_power <- function(dt,method,short.lab=FALSE){
#   dt <- dt[dt$method==method,]
#   dt <- rbind(dt,dt2)
#   dt$cf <- factor(dt$cf,levels=c("none","cov2","cov2+3","no borrowing"))
#   pp <- ggline(dt,y="power", x="ssExt",
#                color = "cf", 
#                linetype = "cf",
#                ylim = c(0.4,1),
#                xlim = c(50,450),
#                ylab = "Power",
#                xlab = "Ext ctrl sample size",numeric.x.axis = T)+
#     theme(plot.title = element_text(hjust = 0.5),
#           legend.position = "right",
#           strip.text = element_text(size=14),
#           axis.text.x = element_text(angle = 45,size = 10,vjust = 0.5))
#   
#   if(!short.lab){
#     pp <- facet(pp,facet.by = "setting",panel.labs=list(setting=c("Large difference","No difference","Large reverse")))
#   }else{
#     pp <- facet(pp,facet.by = "setting")
#   }
#   pp
# }
# 
# plot_t1e <- function(dt,method,short.lab=FALSE){
#   dt <- dt[dt$method==method,]
#   dt <- rbind(dt,dt2)
#   dt$cf <- factor(dt$cf,levels=c("none","cov2","cov2+3","no borrowing"))
#   
#   pp <- ggline(dt,y="t1e", x="ssExt",
#                color = "cf", 
#                linetype = "cf",
#                ylim = c(0,0.2),
#                xlim = c(50,450),
#                ylab = "T1E",
#                xlab = "Ext ctrl sample size",numeric.x.axis = T)+
#     theme(plot.title = element_text(hjust = 0.5),
#           legend.position = "right",
#           legend.text = element_text(size=14),
#           strip.text = element_text(size=14),
#           axis.text.x = element_text(angle = 45,size = 10,vjust = 0.5))
#   
#   if(!short.lab){
#     pp <- facet(pp,facet.by = "setting",panel.labs=list(setting=c("Large difference","No difference","Large reverse")))
#   }else{
#     pp <- facet(pp,facet.by = "setting")
#   }
#   pp
# }

#path_list <- c("","weighting/trimming_0/","weighting/trimming_0.1/")
ssExt.list <- c(100,200,400)
trim <- "trimming_0.1"
cf.list <- c("none","cov2","cov2+3")
round.list <- c("No confounding","One confounder","Two confounders")

for(t in 1:3){
  round <- round.list[[t]]
  for(r in 1:3){
    load(paste0(round,"/CA+M_",ssExt.list[r],"_H0.RData"))
    temp <- final[final$prior=="cauchy",]
    temp$ssExt <- ssExt.list[r]
    if(r==1){
      final.h0 <- temp
    }else{
      final.h0 <- rbind(final.h0,temp)
    }
    
    load(paste0(round,"/CA+M_",ssExt.list[r],"_Ha.RData"))
    temp <- final[final$prior=="cauchy",]
    temp$ssExt <- ssExt.list[r]
    if(r==1){
      final.ha <- temp
    }else{
      final.ha <- rbind(final.ha,temp)
    }
  }
  
  for(r in 1:3){
    load(paste0(round,"/W_",ssExt.list[r],"_H0.RData"))
    final$method <- "weighting(trim 0.1)"
    final$ssExt <- ssExt.list[r]
    final.h0 <- rbind(final.h0,final)
    
    load(paste0(round,"/W_",ssExt.list[r],"_Ha.RData"))
    final$method <- "weighting(trim 0.1)"
    final$ssExt <- ssExt.list[r]
    final.ha <- rbind(final.ha,final)
  }
  
  dt <- final.ha[,-c(5:16)]
  dt$power <- final.ha$reject
  dt$bias <- final.ha$bias
  dt$mse <- final.ha$mse
  dt$t1e <- final.h0$reject
  dt$bias0 <- final.h0$bias
  dt$mse0 <- final.h0$mse
  dt$setting <- ifelse(dt$setting=="L_diff","L_rev",ifelse(dt$setting=="L_rev","L_diff","No_diff"))
  dt$setting <- factor(dt$setting,levels = c("L_diff","No_diff","L_rev"))
  dt$cf <- cf.list[t]
  
  txt <- paste0("tab",t,"<-dt")
  eval(parse(text=txt))
}

dt <- rbind(tab1,tab2,tab3)
dt$ssExt <- as.numeric(dt$ssExt)

## No borrowing (Cox model)
load("cox_marginal.RData")
out <- out[-1,]
colnames(out) <- c("HR","reject","mean","bias","mse","prior","method","setup","ssExt","cf")
out <- data.frame(out)
out <- out[out$cf=="none",]
out.ha <- out[out$HR==0.67 & out$method=="None",]
out.h0 <- out[out$HR==1 & out$method=="None",]

dt2 <- data.frame(matrix(NA,nrow=dim(out.ha)[1],ncol=4))
colnames(dt2) <- colnames(dt)[1:4]
dt2$setting <- ifelse(out.ha$setup=="L_diff","L_rev",ifelse(out.ha$setup=="L_rev","L_diff","No_diff"))
dt2$method <- ifelse(out.ha$prior=="full_ext","full borrowing","no borrowing")
dt2$ssExt <- out.ha$ssExt
dt2$power <- as.numeric(out.ha$reject)
dt2$bias <- out.ha$bias
dt2$mse <- out.ha$mse
dt2$t1e <- as.numeric(out.h0$reject)
dt2$bias0 <- out.h0$bias
dt2$mse0 <- out.h0$mse
dt2 <- dt2[dt2$ssExt!=1000,]
dt2 <- dt2[dt2$method=="no borrowing",]
dt2$cf <- "No borrowing"
dt2$ssExt <- as.numeric(dt2$ssExt)

method_list <- sort(unique(dt$method))
for(m in 1:length(method_list)){
  txt <- paste0("p",m,".1<-plot_t1e(dt,method='",method_list[m],"')")
  eval(parse(text=txt))
  txt <- paste0("p",m,".2<-plot_power(dt,method='",method_list[m],"')")
  eval(parse(text=txt))
}

jpeg("figure3.jpeg",width = 900,height = 1000)
ggarrange(p1.1,p1.2,p2.1,p2.2,p3.1,p3.2,
                     labels=c("A","B","C","D","E","F"),
                     nrow=3,ncol=2,common.legend = T,legend="bottom")
dev.off()

jpeg("figure3-transpose.jpeg",width = 1300,height = 600)
ggarrange(p1.1,p2.1,p3.1,p1.2,p2.2,p3.2,
          labels=c("A","B","C","D","E","F"),
          nrow=2,ncol=3,common.legend = T,legend="bottom")
dev.off()
