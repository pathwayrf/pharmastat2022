rm(list=ls())
library(ggpubr)

## prepare data
## CA(cond), matching, weighting(trim 0.1), no borrow(cox), full borrow(Bayesian)
setwd("~/Project/DLBCL")

## Plotting functions
plot_power <- function(dt,short.lab=FALSE){
  pp <- ggline(dt,y="power", x="ssExt",
               color = "method",
               linetype = "method",
               ylim = c(0.4,1),
               xlim = c(50,450),
               ylab = "Power",
               xlab = "External control sample size",numeric.x.axis = T)+
    scale_color_manual(values = c("#000000","#E41A1C","#377EB8","#4DAF4A","#984EA3"))+
    scale_linetype_manual(values=c("solid","dashed", "twodash","longdash","dotted"))+
    #scale_color_brewer(palette="Set1")
    theme(plot.title = element_text(hjust = 0.5),
          text = element_text(size = 16),
          legend.position = "right",
          legend.key.size = unit(2, 'cm')#,
          #legend.text = element_text(size=14),
          #legend.title = element_text(size=16)
    )
  
  if(!short.lab){
    pp <- facet(pp,facet.by = "setting",panel.labs=list(setting=c("Large difference","No difference","Large reverse")))
  }else{
    pp <- facet(pp,facet.by = "setting")
  }
  pp
}

plot_t1e <- function(dt,short.lab=FALSE){
  pp <- ggline(dt,y="t1e", x="ssExt",
               color = "method", 
               linetype = "method",
               ylim = c(0,0.1),
               xlim = c(50,450),
               ylab = "T1E",
               xlab = "External control sample size",numeric.x.axis = T)+
    scale_color_manual(values = c("#000000","#E41A1C","#377EB8","#4DAF4A","#984EA3"))+
    scale_linetype_manual(values=c("solid","dashed", "twodash","longdash","dotted"))+
    geom_hline(yintercept = 0.025,linetype = "dashed")+
    theme(plot.title = element_text(hjust = 0.5),
          text = element_text(size = 16),
          legend.position = "right",
          legend.key.size = unit(2, 'cm')#,
          #legend.text = element_text(size=14),
          #legend.title = element_text(size=16)
          )
  
  if(!short.lab){
    pp <- facet(pp,facet.by = "setting",panel.labs=list(setting=c("Large difference","No difference","Large reverse")))
  }else{
    pp <- facet(pp,facet.by = "setting")
  }
  pp
}

## No borrowing (Cox model)
load("cox_conditional.RData")
out <- out[-1,]
colnames(out) <- c("HR","reject","mean","bias","mse","prior","method","setup","ssExt","cf") # "cf" means confounding scenarios
out <- data.frame(out)
out <- out[out$cf=="none",]
out <- out[out$prior=="no_ext",]
out.ha <- out[out$HR==0.67 & out$method=="None",]
out.h0 <- out[out$HR==1 & out$method=="None",]

dt2 <- data.frame(matrix(NA,nrow=dim(out.ha)[1],ncol=4))
colnames(dt2) <- colnames(dt)[1:4]
dt2$setting <- ifelse(out.ha$setup=="L_diff","L_rev",ifelse(out.ha$setup=="L_rev","L_diff","No_diff"))
dt2$method <- "No borrowing"
dt2$ssExt <- out.ha$ssExt
dt2$power <- as.numeric(out.ha$reject)
dt2$bias <- out.ha$bias
dt2$mse <- out.ha$mse
dt2$t1e <- as.numeric(out.h0$reject)
dt2$bias0 <- out.h0$bias
dt2$mse0 <- out.h0$mse
dt2 <- dt2[dt2$ssExt!=1000,]

#path_list <- c("","weighting/trimming_0/","weighting/trimming_0.1/")
ssExt.list <- c(100,200,400)
cf.list <- c("No confounding","One confounder","Two confounders")
trim <- "trimming_0.1"


t <- 1 # Prepare data for no confounding scenarios
#for(t in 1:3){ # if we want all scenarios, use this loop
cf <- cf.list[[t]]
  for(r in 1:3){
    load(paste0(cf,"/CA+M_",ssExt.list[r],"_H0.RData"))
    temp <- final[final$prior=="cauchy" | final$prior=="full_ext",]
    temp$ssExt <- ssExt.list[r]
    if(r==1){
      final.h0 <- temp
    }else{
      final.h0 <- rbind(final.h0,temp)
    }
    
    load(paste0(cf,"/CA+M_",ssExt.list[r],"_Ha.RData"))
    temp <- final[final$prior=="cauchy" | final$prior=="full_ext",]
    temp$ssExt <- ssExt.list[r]
    if(r==1){
      final.ha <- temp
    }else{
      final.ha <- rbind(final.ha,temp)
    }
  }
  
  final.h0 <- final.h0[final.h0$prior=="cauchy" | final.h0$method=="CA",]
  final.h0$method[final.h0$prior=="full_ext"] <- "Full borrowing"
  final.ha <- final.ha[final.ha$prior=="cauchy" | final.ha$method=="CA",]
  final.ha$method[final.ha$prior=="full_ext"] <- "Full borrowing"
  
  for(r in 1:3){
    load(paste0(cf,"/W_",ssExt.list[r],"_H0.RData"))
    final$method <- "Weighting"
    final$ssExt <- ssExt.list[r]
    final.h0 <- rbind(final.h0,final)
    
    load(paste0(cf,"/W_",ssExt.list[r],"_Ha.RData"))
    final$method <- "Weighting"
    final$ssExt <- ssExt.list[r]
    final.ha <- rbind(final.ha,final)
  }
  
  dt <- final.ha[,-c(5:16)]
  dt$power <- final.ha$reject
  dt$bias <- final.ha$bias
  dt$mse <- final.ha$mse
  dt$t1e <- final.h0$reject
  dt$bias0 <- final.h0$bias
  dt$mse0 <- final.h0$mse
  dt$setting <- ifelse(dt$setting=="L_diff","L_rev",ifelse(dt$setting=="L_rev","L_diff","No_diff"))
  dt$setting <- factor(dt$setting,levels = c("L_diff","No_diff","L_rev"))
  
  colnames(dt2)[1:4] <- colnames(dt)[1:4]
  dt <- rbind(dt,dt2)
  
  dt$ssExt <- as.numeric(dt$ssExt)
  
  mapping = c("Matching"="M+DB","CA"="A+DB","Weighting"="W+DB",
              "Full borrowing"="A+P","No borrowing"="A+C")
  dt$method <- unlist(unname(sapply(dt$method,function(x) do.call("switch",as.list(c(x,mapping))))))
  
  txt <- paste0("p",t,".1<-plot_power(dt)")
  eval(parse(text=txt))
  txt <- paste0("p",t,".2<-plot_t1e(dt)")
  eval(parse(text=txt))
#}

                                    
jpeg("figure2.jpeg",width = 1000,height = 400)
ggarrange(p1.2,p1.1,
          labels=c("A","B"),
          nrow=1,ncol=2,common.legend = T,legend="bottom")
dev.off()













            
