rm(list=ls())

## prepare data
## CA(cond), matching, weighting(no trim), weighting(trim 0.1), no borrow(cox), full borrow(cox)
setwd("~/Project/DLBCL")

#path_list <- c("","weighting/trimming_0/","weighting/trimming_0.1/")
ssExt.list <- c(100,200,400)
round.list <- list(1:3,5:7,9:11)
cf.list <- c("No confounder","One confounder","Two confouders")
trim <- "trimming_0.1"

t <- 1
#for(t in 1:3){
  round <- round.list[[t]]
  for(r in 1:3){
    load(paste0("round",r,"/H0.RData"))
    temp <- final[final$prior=="cauchy",]
    temp$ssExt <- ssExt.list[r]
    temp$cf <- cf.list[t]
    if(r==1 & t==1){
      final.h0 <- temp
    }else{
      final.h0 <- rbind(final.h0,temp)
    }
    
    load(paste0("round",r,"/Ha.RData"))
    temp <- final[final$prior=="cauchy",]
    temp$ssExt <- ssExt.list[r]
    temp$cf <- cf.list[t]
    if(r==1 & t==1){
      final.ha <- temp
    }else{
      final.ha <- rbind(final.ha,temp)
    }
  }
  
  for(r in 1:3){
    load(paste0("weighting/round",round[r],"/H0.RData"))
    final$method <- "Weighting"
    final$ssExt <- ssExt.list[r]
    final$cf <- cf.list[t]
    final.h0 <- rbind(final.h0,final)
    
    load(paste0("weighting/round",round[r],"/Ha.RData"))
    final$method <- "Weighting"
    final$ssExt <- ssExt.list[r]
    final$cf <- cf.list[t]
    final.ha <- rbind(final.ha,final)
  }
#}

dt <- final.ha[,-c(5:16)]
dt$est <- final.ha$mean_HR_trt_cc
dt$power <- final.ha$reject
dt$bias <- final.ha$bias
dt$mse <- final.ha$mse
dt$t1e <- final.h0$reject
dt$est0 <- final.h0$mean_HR_trt_cc
dt$bias0 <- final.h0$bias
dt$mse0 <- final.h0$mse
dt$setting <- ifelse(dt$setting=="L_diff","L_rev",ifelse(dt$setting=="L_rev","L_diff","No_diff"))
dt$setting <- factor(dt$setting,levels = c("L_diff","No_diff","L_rev"))
dt$cf <- final.ha$cf

table <- data.frame(matrix(ncol=12,nrow=2))
table[1,c(4,7,10)] <- c("CA","Matching","Weighting")
table[2,4:12] <- rep(c("estimate","bias","mse"),3)

method.list <- c("CA","Matching","Weighting")
setup.list <- c("L_rev","No_diff","L_diff")

for(l in 1:3){
  tab <- data.frame(matrix(ncol=11,nrow=18))
  tab[seq(1,13,by=6),1] <- c("Large difference","No difference","Large difference reverse")
  tab[,2] <- rep(rep(c(100,200,400),each=2),3)
  n.digits <- 3
  for(i in 1:3){
    for(j in 1:3){
      for(k in 1:3){
        tab[6*(i-1)+2*(k-1)+1,3*j] <- format(round(dt$est[dt$ssExt==tab[6*(i-1)+2*(k-1)+1,2] & dt$setting==setup.list[i] & dt$method==method.list[j] & dt$cf==cf.list[l]],digits = n.digits),nsmall=n.digits)
        tab[6*(i-1)+2*(k-1)+1,3*j+1] <- format(round(dt$bias[dt$ssExt==tab[6*(i-1)+2*(k-1)+1,2] & dt$setting==setup.list[i] & dt$method==method.list[j] & dt$cf==cf.list[l]],digits = n.digits),nsmall=n.digits)
        tab[6*(i-1)+2*(k-1)+1,3*j+2] <- format(round(dt$mse[dt$ssExt==tab[6*(i-1)+2*(k-1)+1,2] & dt$setting==setup.list[i] & dt$method==method.list[j] & dt$cf==cf.list[l]],digits = n.digits),nsmall=n.digits)
        
        tab[6*(i-1)+2*(k-1)+2,3*j] <- format(round(dt$est0[dt$ssExt==tab[6*(i-1)+2*(k-1)+1,2] & dt$setting==setup.list[i] & dt$method==method.list[j] & dt$cf==cf.list[l]],digits = n.digits),nsmall=n.digits)
        tab[6*(i-1)+2*(k-1)+2,3*j+1] <- format(round(dt$bias0[dt$ssExt==tab[6*(i-1)+2*(k-1)+1,2] & dt$setting==setup.list[i] & dt$method==method.list[j] & dt$cf==cf.list[l]],digits = n.digits),nsmall=n.digits)
        tab[6*(i-1)+2*(k-1)+2,3*j+2] <- format(round(dt$mse0[dt$ssExt==tab[6*(i-1)+2*(k-1)+1,2] & dt$setting==setup.list[i] & dt$method==method.list[j] & dt$cf==cf.list[l]],digits = n.digits),nsmall=n.digits)
      }
    }
  }
  tab <- cbind(c(cf.list[l],rep(NA,17)),tab)
  colnames(tab) <- colnames(table)
  table <- rbind(table,tab)
}


#writexl::write_xlsx(table,path="table1.xlsx",col_names = F)

load("cox_conditional.RData")
out <- out[-1,]
colnames(out) <- c("HR","reject","mean","bias","mse","prior","method","setup","ssExt","cf")
out <- data.frame(out)
#out <- out[out$cf=="none",]
#out <- out[out$prior=="no_ext",]
out.ha <- out[out$HR==0.67 & out$method=="None",]
out.h0 <- out[out$HR==1 & out$method=="None",]

dt2 <- data.frame(matrix(NA,nrow=dim(out.ha)[1],ncol=4))
colnames(dt2) <- colnames(dt)[1:4]
dt2$setting <- ifelse(out.ha$setup=="L_diff","L_rev",ifelse(out.ha$setup=="L_rev","L_diff","No_diff"))
dt2$method <- out.h0$prior
dt2$ssExt <- as.numeric(out.ha$ssExt)
dt2$est <- as.numeric(out.ha$mean)
dt2$bias <- as.numeric(out.ha$bias)
dt2$mse <- as.numeric(out.ha$mse)
dt2$est0 <- as.numeric(out.h0$mean)
dt2$bias0 <- as.numeric(out.h0$bias)
dt2$mse0 <- as.numeric(out.h0$mse)
dt2$cf <- out.h0$cf

method.list <- unique(dt2$method)
cf.list <- c("none","cov2","cov2+3")
table2 <- data.frame(matrix(ncol=6,nrow=2))
table2[1,c(1,4)] <- c("No borrowing","Full borrowing")
table2[2,] <- rep(c("estimate","bias","mse"),2)
for(l in 1:3){
  tab <- data.frame(matrix(ncol=6,nrow=18))
  n.digits <- 3
  for(i in 1:3){
    for(j in 1:2){
      for(k in 1:3){
        tab[6*(i-1)+2*(k-1)+1,3*(j-1)+1] <- format(round(dt2$est[dt2$ssExt==ssExt.list[k] & dt2$setting==setup.list[i] & dt2$method==method.list[j] & dt2$cf==cf.list[l]],digits = n.digits),nsmall=n.digits)
        tab[6*(i-1)+2*(k-1)+1,3*(j-1)+2] <- format(round(dt2$bias[dt2$ssExt==ssExt.list[k] & dt2$setting==setup.list[i] & dt2$method==method.list[j] & dt2$cf==cf.list[l]],digits = n.digits),nsmall=n.digits)
        tab[6*(i-1)+2*(k-1)+1,3*j] <- format(round(dt2$mse[dt2$ssExt==ssExt.list[k] & dt2$setting==setup.list[i] & dt2$method==method.list[j] & dt2$cf==cf.list[l]],digits = n.digits),nsmall=n.digits)
        
        tab[6*(i-1)+2*(k-1)+2,3*(j-1)+1] <- format(round(dt2$est0[dt2$ssExt==ssExt.list[k] & dt2$setting==setup.list[i] & dt2$method==method.list[j] & dt2$cf==cf.list[l]],digits = n.digits),nsmall=n.digits)
        tab[6*(i-1)+2*(k-1)+2,3*(j-1)+2] <- format(round(dt2$bias0[dt2$ssExt==ssExt.list[k] & dt2$setting==setup.list[i] & dt2$method==method.list[j] & dt2$cf==cf.list[l]],digits = n.digits),nsmall=n.digits)
        tab[6*(i-1)+2*(k-1)+2,3*j] <- format(round(dt2$mse0[dt2$ssExt==ssExt.list[k] & dt2$setting==setup.list[i] & dt2$method==method.list[j] & dt2$cf==cf.list[l]],digits = n.digits),nsmall=n.digits)
      }
    }
  }
  table2 <- rbind(table2,tab)
}

table <- cbind(table,table2)
writexl::write_xlsx(table,path="table1.xlsx",col_names = F)
