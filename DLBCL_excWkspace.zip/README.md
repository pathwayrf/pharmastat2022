Examples are given for implementing each methods.
