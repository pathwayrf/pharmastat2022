library(doParallel)
library(foreach)
library(rjags)

run_mcmc_p <- function(dt, priorObj, n.chains, n.adapt, n.burn, n.iter, seed, path, HR_type="conditional"){
  
  if (missing(dt)) stop("Please provide a list of simulated time (dt).")
  if (missing(priorObj)) stop("Please provide .priorObj (priorObj).")
  #n_mcmc <- valid_mcmc(n.chains, n.adapt, n.burn, n.iter)
  
  if (missing(seed)){
    message("Set.seed(47)")
    seed = 47
  }
  seed_list <- seq(seed, seed + length(dt), by = 1)
  
  #flog.debug(cat("seed_list:", seed_list, "number of dataset", length(dt), "\n"))
  
  nCluster <- parallel::detectCores()
  print(paste(nCluster, "clusters are being used"))
  cl <- parallel::makeCluster(nCluster)
  doParallel::registerDoParallel(cl)
  
  
  res_list <- foreach(i = 1:length(dt), .combine='c', .multicombine=TRUE,.packages = c("psborrow","rjags","simsurv","survival"),
                      .export = c("add_mcmc","ad_est","r_post","rej_est","ad_est","adjust_margin"),
                      # .export = c("format_number", "format_date_time", "add_direction_data"),
                      # .packages = c("tidyverse", "data.table", "dplyr", "rjags"),
                      .verbose=FALSE) %dopar% {
                        
                        seed_i = seed_list[i]
                        
                        print(paste("-------------------", i, "of ", length(dt), "simulated dataset with seed =", seed_i))
                        
                        add_mcmc(dt = dt[[i]], priorObj = priorObj,
                                 n.chains = n.chains, n.adapt = n.adapt,
                                 n.burn = n.burn, n.iter = n.iter, seed = seed_i)
                      } #loop foreach
  
  parallel::stopCluster(cl)
  sum_list <- lapply(res_list, function(i) {
    if(HR_type=="conditional"){
      cbind("HR" = i[['HR']], "driftHR" = i[['driftHR']],
            "prior" = i[['prior']], "pred" = i[['pred']],
            "reject" = i[['summary']]['reject'],
            "mean_HR" = i[['summary']]['mean_HR'],
            "sd_HR" = i[['summary']]['sd_HR'],
            "mean_driftHR" = i[['summary']]['mean_driftHR'],
            "sd_driftHR" = i[['summary']]['sd_driftHR'])
    }else{
      cbind("HR" = i[['HR']], "driftHR" = i[['driftHR']],
            "prior" = i[['prior']], "pred" = i[['pred']],
            "reject" = i[['summary_admargin']]['reject'],
            "mean_HR" = i[['summary_admargin']]['mean_HR'],
            "sd_HR" = i[['summary_admargin']]['sd_HR'],
            "mean_driftHR" = i[['summary']]['mean_driftHR'],
            "sd_driftHR" = i[['summary']]['sd_driftHR']) 
      }
    })
    
  sum_dt <- as.data.frame(do.call(rbind, sum_list))
  rownames(sum_dt) <- NULL
  sum_dt$HR = as.numeric(sum_dt$HR)
  sum_dt$driftHR = as.numeric(sum_dt$driftHR)
  sum_dt$reject = as.numeric(sum_dt$reject)
  sum_dt$mean_HR = as.numeric(sum_dt$mean_HR)
  sum_dt$sd_HR = as.numeric(sum_dt$sd_HR)
  sum_dt$mean_driftHR = as.numeric(sum_dt$mean_driftHR)
  sum_dt$sd_driftHR = as.numeric(sum_dt$sd_driftHR)
  
  if (missing(path)) print("Samples from the posterior distribution from MCMC are not saved.") else {
    save(sum_dt, file = path)
    print(paste("Results the posterior distribution from MCMC are saved as", path))
  }
  sum_dt
}

add_mcmc <- function(dt, priorObj, n.chains, n.adapt, n.burn,  n.iter, seed){
  
  if (missing(dt)) {
    stop ("Please provide a dataset (dt).")
  } else {
    cov_name = colnames(dt)[!colnames(dt) %in% c("driftHR", "HR", "trt", "ext", "time", "cnsr", "wgt")] #extract covariate names in the dataset
    if (sum(!c("driftHR", "HR", "trt", "ext", "time", "cnsr") %in% colnames(dt)) > 0 ) stop("Please make sure the trial data contains at least trt, ext, time and cnsr.")
    else if (sum(!grepl("cov[1234567890]", cov_name)) > 0) stop("Please make sure the covariates in the trial have the right name.")
  }
  #flog.debug(cat("[add_mcmc] cov_name =", cov_name, "\n"))
  
  if (missing(seed)){
    message("Set.seed(47)")
    seed = 47
  }
  
  #n_mcmc <- valid_mcmc(n.chains, n.adapt, n.burn, n.iter)
  
  if (length(priorObj) == 1) priorObj = c(priorObj)
  
  lapply(seq(1, length(priorObj), by = 1), function(i){
    prior = priorObj[[i]]@prior
    pred = priorObj[[i]]@pred
    
    #---
    if (missing(pred)) {
      pred = "none"
      message("Predictors to include in the weibull distribution (pred) is not provided. No predictor is used.")
    } else if (sum(!pred %in% c(cov_name, "none", "ps", "all")) > 0 ){
      stop("pred is not correctly specified. Options include none, ps, all and covariate names start with cov.")
    } else if (sum(grepl("none", pred)) > 0) {
      pred = "none"
      message("Input none is found in pred. Any other input is disregarded.")
    } else if (sum(grepl("all", pred)) > 0) {
      pred = "all"
      message("Input all is found in pred. Any other input is disregarded.")
    } else if (sum(grepl("ps", pred)) == 0) {
      message(cat("Selected covariate(s)", pred, "are used as predictors in the weibull distribution.\n"))
    } else if (sum(grepl("ps", pred)) > 0 & length(pred) == 1){ # column wgt does not exist
      dt_ps <- c_ps(dt, cov_name)
      message(cat("Propensity score calculated using all coariates", cov_name, "is used as predictors in the weibull distribution.\n"))
    } else if (sum(grepl("ps", pred)) > 0 & ("wgt" %in% colnames(dt))) { # column wgt already existed
      message("Weight already provided in the data. It is used as predictor directly. \n")
    } else if (sum(grepl("ps", pred)) > 0 & length(pred) > 1){
      message(cat("Propensity score calculated based selected covariate(s)", pred[pred != "ps"],
                  "is used as predictors in the weibull distribution.\n"))
    }
    
    #flog.debug(cat(">>> prior =", prior, ", pred = ", pred, "\n"))
    
    mcmc_res <- r_post(dt = dt,
                       prior = prior, pred = pred,
                       r0 = priorObj[[i]]@r0, alpha = priorObj[[i]]@alpha,
                       sigma = priorObj[[i]]@sigma, seed = seed,
                       
                       n.chains = n.chains, n.adapt = n.adapt,
                       n.burn = n.burn, n.iter = n.iter)
    
    mcmc_sum <- rej_est(mcmc_res)
    #flog.debug(cat(">>> mcmc_sum =", mcmc_sum, "\n"))
    ad <- adjust_margin(mcmc_list = mcmc_res,dt=dt,pred=pred)
    ad_sum <- ad_est(ad)
    list("HR" = unique(dt[, 'HR']),
         "driftHR" = unique(dt[, 'driftHR']),
         "prior" = prior,
         "pred" = paste(pred, collapse = " "), # print to one row
         "mcmc.list" = mcmc_res, "summary" = mcmc_sum,"summary_admargin" = ad_sum)
  })
}

r_post <- function(dt,
                   prior, pred,
                   r0, alpha, sigma,
                   n.chains, n.adapt, n.burn, n.iter, seed){
  #flog.debug(cat("[r_post] dt =", colnames(dt), "\n"))
  cov_name = colnames(dt)[!colnames(dt) %in% c("driftHR", "HR", "trt", "ext", "time", "cnsr", "wgt")]
  #flog.debug(cat("[r_post] cov_name =", cov_name, "\n"))
  
  # pred = c("ps", "cov1")
  # dt is a matrix
  if (sum(grepl("none", pred)) > 0) {
    x = dt[,c("trt"),drop=FALSE]
    n_cov = 0
    #flog.debug("No covariates are used as predictors in the weibull distribution. Any other input is disregarded.\n")
  } else if (sum(grepl("all", pred)) > 0) {
    x = dt[,c("trt", cov_name)]
    n_cov = length(cov_name)
    #flog.debug(cat("All covariates", cov_name, "are used as predictors in the weibull distribution. Any other input is disregarded. \n"))
  } else if (sum(grepl("ps", pred)) == 0) {
    x = dt[,c("trt", pred)]
    n_cov = length(pred)
    #flog.debug(cat("Selected covariate(s)", pred, "are used as predictors in the weibull distribution. Any other input is disregarded. \n"))
  } else if (sum(grepl("ps", pred)) > 0 & ("wgt" %in% colnames(dt))) { # column wgt already existed
    x = dt[,c("trt", "wgt")]
    n_cov = 1
    #flog.debug("Weight already provided in the data. It is used as predictor directly. \n")
  } else if (sum(grepl("ps", pred)) > 0 & length(pred) == 1){ # column wgt does not exist
    dt_ps <- c_ps(dt, cov_name)
    x = dt_ps[,c("trt", "wgt")]
    n_cov = 1
    #flog.debug(cat("Propensity score is calculated based on all coariates", cov_name, "are used as predictors in the weibull distribution.\n"))
  } else if (sum(grepl("ps", pred)) > 0 & length(pred) > 1){
    dt_ps <- c_ps(dt, pred[pred != "ps"])
    x = dt_ps[,c("trt", "wgt")]
    n_cov = 1
    #flog.debug(cat("Propensity score calculated based selected covariate(s)", pred[pred != "ps"],
    #               "ise used as predictors in the weibull distribution.\n"))
  }
  
  data_list = list(N = nrow(dt), timev = dt[,'time'], event = 1-dt[,'cnsr'], ext = dt[,'ext'] +1, n_cov = n_cov, x = x)
  inits_list = list(.RNG.name="base::Super-Duper", .RNG.seed = seed, r0 = r0, alpha = alpha, beta = rep(0, n_cov + 1)) #.RNG.seed = 1,
  
  out_list = c("alpha", "beta", "r0", "HR_trt_cc", "HR_cc_hc")
  
  if (prior == "full_ext") {
    prior = "no_ext"
    data_list = list(N = nrow(dt), timev = dt[,'time'], event = 1-dt[,'cnsr'], n_cov = n_cov, x = x)
    
  } else if (prior == "no_ext") { # no borrow
    dt2 = dt[dt[, "ext"] == 0,] #remove external trial data
    
    if (sum(grepl("none", pred)) > 0) {
      x = dt2[,c("trt"),drop=FALSE]
    } else if (sum(grepl("all", pred)) > 0) {
      x = dt2[,c("trt", cov_name)]
    } else {
      x = dt2[,c("trt", pred)]
    }
    
    data_list = list(N = nrow(dt2), timev = dt2[,'time'], event = 1-dt2[,'cnsr'], n_cov = n_cov, x = x)
    
  } else if (prior == "cauchy" | prior == "unif") {
    inits_list = list(.RNG.name = "base::Super-Duper", .RNG.seed = seed, r0 = r0, alpha = alpha, beta = rep(0, n_cov + 1), sigma = sigma) #.RNG.seed = 1,
    out_list = c("alpha", "beta",  "r0", "prec", "HR_trt_cc", "HR_cc_hc")
    
  } else if (prior == "gamma") {
    out_list = c("alpha", "beta", "r0", "tau", "HR_trt_cc", "HR_cc_hc")
  }
  
  prior_txt = system.file("model", paste0(prior, ".txt"), package = "psborrow")
  # prior_txt = paste0("inst/model/", prior, ".txt")
  
  
  #flog.debug(cat("[r_post] N =", data_list[['N']], "event =", sum(data_list[['event']] == 1),
  #               "ext =", ifelse(is.null(data_list[['ext']]), NA, sum(data_list[['ext']] == 2)),
  #               "n_cov =", data_list[['n_cov']], "x =", colnames(data_list[['x']]), "\n"
  #))
  #flog.debug(cat("[r_post] r0 =", inits_list[['r0']],
  #               "alpha =", inits_list[['alpha']], "beta =", inits_list[['beta']],
  #               "sigma =", ifelse(is.null(inits_list[['sigma']]), NA, inits_list[['sigma']]),
  #               ".RNG.seed = ", seed, "\n"
  #))
  
  jags.out <- jags.model(prior_txt,
                         data = data_list,
                         inits = inits_list,
                         n.chains = n.chains, n.adapt = n.adapt, quiet=TRUE)
  
  # set.seed(314)
  update(jags.out, n.burn = n.burn)
  jags.sample <- coda.samples(jags.out, out_list, n.iter = n.iter)
  print(summary(jags.sample))
  jags.sample
}

rej_est = function(samples){
  summ = summary(samples)[[1]]
  quantiles <- summary(samples)[[2]]
  reject = quantiles["HR_trt_cc","97.5%"] < 1
  mean_HR  =  summ["HR_trt_cc","Mean"]
  sd_HR = summ["HR_trt_cc","SD"]
  # post_median_hr_trt_cc = quantiles["HR_trt_cc","50%"]
  mean_driftHR  =  summ["HR_cc_hc", "Mean"]
  sd_driftHR = summ["HR_cc_hc","SD"]
  print(paste("reject", reject,
              "mean_HR", mean_HR, "sd_HR", sd_HR,
              "mean_driftHR", mean_driftHR,  "sd_driftHR", sd_driftHR))
  c("reject" = reject,
    "mean_HR" = mean_HR, "sd_HR" = sd_HR,
    "mean_driftHR"  = mean_driftHR,  "sd_driftHR"  = sd_driftHR)
}
