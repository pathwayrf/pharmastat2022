## The following function conduct a one-to-one matching for external control subjects which required in the "Example-matching.R".

library(MatchIt)
library(dplyr)
m_cov <- function(dt, match.formula){
  dt2 <- data.frame(dt)
  dt2$int = 1 - dt2$ext
  
  m.out <- matchit(as.formula(match.formula), method = "nearest", ratio = 1, caliper = 0.2, data = dt2)
  #matchit(ext ~ cov1 + cov2, method = "nearest", ratio = 1, caliper = 0.2, data = sample_cov.df) # match on all covariates
  
  dt.match <- match.data(m.out)
  
  print(paste0(nrow(dt2[dt2$ext == 1,]) - nrow(dt.match[dt.match$ext == 1,]), " patients from the external arm are excluded, ", nrow(dt2[dt2$int == 1,]) - nrow(dt.match[dt.match$int == 1,]), " patients from the internal trial are excluded."))
  
  dt.match_ext <- dt.match[dt.match$ext == 1, !colnames(dt.match) %in% c("distance", "weights", "subclass")]
  
  dt_int = dt2[dt2$ext == 0,]
  dt.match_ext <- as.data.frame(dt.match_ext)
  match.all <- as.matrix(rbind(dt.match_ext, dt_int) %>% select(-"int"))
  print(paste0("After matching, we have ", nrow(match.all), " patients in total."))
  return(match.all)
}


match_cov <- function(dt, match) {
  if (missing(dt)) stop("Please provide a list of simulated data (dt).")
  if (missing(match)) {
    stop("Please provide covariates name to match on.")
  } else if (sum(!match %in% colnames(dt[[1]])[!colnames(dt[[1]]) %in% c("driftHR", "HR", "trt", "ext")]) > 0) {
    stop("Please make sure the trial data contains the correct variable names.")
  }
  match.formula <- paste("int ~", paste0(match, collapse=' + '))
  print(match.formula)
  res_list <- lapply(seq(1, length(dt), by = 1), function(i){
    m_cov(dt[[i]], match.formula)
  }) #loop foreach
  
  res_list
}

