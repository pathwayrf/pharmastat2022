rm(list=ls())

setwd("~/project/DLBCL")

## Get job array id and setting from Batch
args <- commandArgs(trailingOnly = TRUE)

print(paste0("i = ", as.numeric(args[1])))
print(paste0("outFile = ", args[2]))

i <- as.numeric(args[1])
seed <- (i-1)*1000+1

## Load package
library(psborrow)
library(survival)
library(doParallel)

registerDoParallel(cores=(Sys.getenv("SLURM_NTASKS_PER_NODE")))

start <- Sys.time()
## Number of observations
ss = set_n(ssC = 140, ssE = 275, ssExt = 100) 

#### Large diff
covset1 = set_cov(n_cat = 2, n_cont = 0, mu_int = rep(0, 2), mu_ext = rep(0, 2), var = rep(1, 2), cov = 0.5, 
                  prob_int = c(0.75, 0.56), prob_ext = c(0.85, 0.64))
covset2 = set_cov(n_cat = 2, n_cont = 0, mu_int = rep(0, 2), mu_ext = rep(0, 2), var = rep(1, 2), cov = 0.3, 
                  prob_int = c(0.31, 0.54), prob_ext = c(0.36, 0.5))
covset3 = set_cov(n_cat = 3, n_cont = 0, mu_int = rep(0, 3), mu_ext = rep(0, 3), var = rep(1, 3), cov = 0.2, 
                  prob_int = c(0.84, 0.38, 0.18), prob_ext = c(0.86, 0.36, 0.15))
covset4 = set_cov(n_cat = 0, n_cont = 1, mu_int = 63, mu_ext = 62.6, var = 11.9^2)

cov_list = c(covset1, covset2, covset3, covset4)

sample_cov <- simu_cov(ssObj = ss, covObj = cov_list, HR = 1, driftHR = 1,nsim=100,seed=seed)

# Enrollment pattern, drop-out, analysis start time
c_int = set_clin(gamma = 10, e_itv = 415/10, etaC = -log(1-0.04/12),  CCOD = "fixed-first", CCOD_t = 60)
c_ext = set_clin(gamma = 100/18, e_itv = 18, etaC = -log(1-0.01/12),  CCOD = "fixed-first", CCOD_t = 70)

# Time-to-event distribution
evt <- set_event(event = "weibull", shape = 0.9, lambdaC = 0.0135, beta = c(1, 0.5, 0.5, rep(0.001, 5)))
sample_time <- simu_time(dt = sample_cov, eventObj = evt, clinInt = c_int, clinExt = c_ext,seed=seed)


# Predictors in the weibull distribution and prior distribution for the precision variable
pr1 <- set_prior(pred = c("cov1", "cov2", "cov3", "cov4", "cov5", "cov6", "cov7","cov8"), prior = "cauchy", r0 = 1, alpha = c(0, 0), sigma = 0.03)
#pr2 <- set_prior(pred = c("cov1", "cov2", "cov3", "cov4", "cov5", "cov6", "cov7","cov8"), prior = "gamma", r0 = 1, alpha = c(0, 0))
#pr3 <- set_prior(pred = c("cov1", "cov2", "cov3", "cov4", "cov5", "cov6", "cov7"), prior = "no_ext", alpha = 0)
#pr4 <- set_prior(pred = c("cov1", "cov2", "cov3", "cov4", "cov5", "cov6", "cov7"), prior = "full_ext", alpha = 0)

pr_list <- c(pr1)

# parallel processing
source("run_mcmc.R")
scenario_cov <- run_mcmc_p(dt = sample_time, pr_list, n.chains = 2, n.adapt = 1000, n.burn = 10000, n.iter = 20000, seed = seed, HR_type = "marginal")

summ <- get_summary(scenario_cov)
head(summ)

end <- Sys.time()
diff_time <- difftime(end, start, units = "auto")
