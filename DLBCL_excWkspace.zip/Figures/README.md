This folder contains the figures for the manuscript. 

The corresponding codes are included in the "plotting" folder.
