The folder contains the source codes for running psborrow without the installation of the R package on sHPC.

The "parallel.sh" is the batch script to submit a parellel computing job to the cluster using "bsub < parallel.sh" command. The memory limit is subject to change.
