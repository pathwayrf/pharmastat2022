rm(list=ls())

library(doParallel)
library(foreach)
library(tidyverse)
library(data.table)
library(dplyr)
library(mvtnorm)
library(MatchIt)
library(futile.logger)
library(rjags)
library(survival)

#setwd("~/project")

source("add_mcmc.R")
source("adjust_margin.R")
source("run_mcmc.R")
source("run_mcmc_np.R")
source("get_summary.R")
source("utils.R")
source("simu_cov.R")
source("add_cov.R")
source("add_time.R")
source("simu_time.R")
source("utils.R")
source("rpwexp.R")
source("match_fun.R")

#args <- commandArgs(trailingOnly = TRUE)

# ssExt <- 100#as.numeric(args[1]) # sample size of external control
# setup <- args[2] # setting for covariate distribution 
# H <- args[3]
# 
# load(paste0("Data/",setup,"_",ssExt,"_",H,".RData"))



# # subset the dataset for each job
# 
# i <- as.numeric(args[4])
# index <- 100*(i-1)+1:100
# 
# sample_time <- sample_time[index]
# sample_time <- lapply(sample_time, function(dt){
#   dt <- cbind(dt,extumatch=0)
# })
# 
# registerDoParallel(cores=(Sys.getenv("SLURM_NTASKS_PER_NODE")))

## Simulate data

ss = set_n(ssC = 140, ssE = 100, ssExt = 100) 


#### Large diff
covset1 = set_cov(n_cat = 2, n_cont = 0, mu_int = rep(0, 2), mu_ext = rep(0, 2), var = rep(1, 2), cov = 0.5, 
                  prob_int = c(0.75, 0.56), prob_ext = c(0.85, 0.64))
covset2 = set_cov(n_cat = 2, n_cont = 0, mu_int = rep(0, 2), mu_ext = rep(0, 2), var = rep(1, 2), cov = 0.3, 
                  prob_int = c(0.31, 0.54), prob_ext = c(0.36, 0.5))
covset3 = set_cov(n_cat = 3, n_cont = 0, mu_int = rep(0, 3), mu_ext = rep(0, 3), var = rep(1, 3), cov = 0.2, 
                  prob_int = c(0.84, 0.38, 0.18), prob_ext = c(0.86, 0.36, 0.15))
covset4 = set_cov(n_cat = 0, n_cont = 1, mu_int = 63, mu_ext = 62.6, var = 11.9^2)

cov_list = c(covset1, covset2, covset3, covset4)

sample_cov <- simu_cov(ssObj = ss, covObj = cov_list, HR = 0.67, driftHR = 1,nsim=5)

# Enrollment pattern, drop-out, analysis start time
c_int = set_clin(gamma = 10, e_itv = 415/10, etaC = -log(1-0.04/12),  CCOD = "fixed-first", CCOD_t = 60)
c_ext = set_clin(gamma = 100/18, e_itv = 18, etaC = -log(1-0.01/12),  CCOD = "fixed-first", CCOD_t = 70)

# Time-to-event distribution
evt <- set_event(event = "weibull", shape = 0.9, lambdaC = 0.0135, beta = c(1, 0.5, 0.5, rep(0.001, 5)))
sample_time <- simu_time(dt = sample_cov, eventObj = evt, clinInt = c_int, clinExt = c_ext)
sample_time <- lapply(sample_time, function(dt){
  dt <- cbind(dt,extumatch=0)
})

# Predictors in the weibull distribution and prior distribution for the precision variable
pr1 <- set_prior(pred = "all", prior = "cauchy", r0 = 1, alpha = c(0, 0), sigma = 0.03)
pr2 <- set_prior(pred = "all", prior = "gamma", r0 = 1, alpha = c(0, 0))
pr3 <- set_prior(pred = "all", prior = "no_ext", alpha = 0)
pr4 <- set_prior(pred = "all", prior = "full_ext", alpha = 0)

#pr_list <- c(pr1, pr2, pr3, pr4)
pr_list <- c(pr1, pr2)

# parallel processing
start <- Sys.time()
scenario_cov <- run_mcmc_np(dt = sample_time, pr_list, n.chains = 2, n.adapt = 100, n.iter = 200, HR_type="marginal")

summ <- get_summary(scenario_cov)
head(summ)

end <- Sys.time()
diff_time <- difftime(end, start, units = "auto")

ncore <- parallel::detectCores()
print(ncore)
save.image(paste0("out/CA-one.RData"))
