#!/bin/bash
# JOB HEADERS HERE

#BSUB -J test_para[1-2]
#BSUB -q preempt
#BSUB -n 1
#BSUB -M 8000
#BSUB -e out/test.err
#BSUB -o out/test.out
#BSUB -W 3:30

singularity exec https://ross.science.roche.com/singularity-cbs/coderoche/r_container/bee_4.1.1.sif Rscript CA-multi.R


echo "Hello World"
