## Number of observations
ss = set_n(ssC = 140, ssE = 275, ssExt = 100) 

# Enrollment pattern, drop-out, analysis start time
c_int = set_clin(gamma = 10, e_itv = 415/10, etaC = -log(1-0.04/12),  CCOD = "fixed-first", CCOD_t = 64)
c_ext = set_clin(gamma = 100/18, e_itv = 18, etaC = -log(1-0.01/12),  CCOD = "fixed-first", CCOD_t = 64)

# Time-to-event distribution
evt <- set_event(event = "weibull", shape = 0.9, lambdaC = 0.0135, beta = c(1, 0.5, 0.5, rep(0.001, 5)))
sample_time <- simu_time(dt = sample_cov, eventObj = evt, clinInt = c_int, clinExt = c_ext, seed = seed)
